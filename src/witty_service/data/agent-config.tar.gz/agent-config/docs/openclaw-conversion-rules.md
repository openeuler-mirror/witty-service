# agent-spec.yaml -> OpenClaw 转换规则（设计版）

> 版本：v0.1（2026-04-03）  
> 适用范围：将 `transfor/agent_template/agent-spec.yaml` 转换为 `~/.openclaw/openclaw.json` 及相关工作区文件。

## 0. 术语与目标
- `opennclaw`、`openclawde` 均统一指 **OpenClaw**。
- 本文仅定义“转换规则与执行顺序”，不包含具体代码实现。
- 第一阶段目标：只落地 OpenClaw 侧转换（非 OpenCode 目标文件）。

## 1. 已确认的官方事实（作为规则依据）

### 1.1 OpenClaw 配置与校验
- 主配置路径由 `openclaw config file` 给出，默认是 `~/.openclaw/openclaw.json`。
- 语法/Schema 校验命令：`openclaw config validate`。
- Schema 可通过 `openclaw config schema` 导出（可作为转换器字段合法性校验基准）。

### 1.2 OpenClaw MCP 写入方式
- `openclaw mcp set <name> <json>` 用于写入单个 MCP server。
- 文档示例的配置形态为：
  - `mcp.servers.<name>.command/args/env`（stdio）
  - `mcp.servers.<name>.url/headers`（remote）

### 1.3 OpenClaw Skills 与 ClawHub
- `clawhub` 支持 `--dir` 指定 skills 目录，且相对 `--workdir` 解析。
- OpenClaw skills 目录层级：
  - 共享：`~/.openclaw/skills`
  - workspace 级：`<workspace>/skills`

### 1.4 OpenCode（用于模型/工具概念对齐）
- OpenCode 配置是 `opencode.json/jsonc`，模型与工具分别通过 `model/provider`、`tools/permission` 配置。
- OpenCode 的 `tools` 在 agent 文档中标注为 deprecated，建议以 `permission` 为主。
- 本项目当前输出目标仍是 OpenClaw，因此只把 OpenCode 作为语义对照，不直接生成 OpenCode 文件。

## 2. 总体转换策略（3 选 1）

### 方案 A：模板渲染 + 全量覆盖（推荐）
- 做法：以 `openclaw-template.json` 为基底，先产出“最小可用集”，再按转换阶段补齐字段并校验。
- 优点：可重复、可审计、便于回归测试。
- 风险：需要处理模板字段漂移。

### 方案 B：命令增量写入（openclaw config set/mcp set）
- 做法：按路径逐条 set。
- 优点：可局部重试。
- 风险：流程长、状态易半完成。

### 方案 C：混合模式（模板生成主配置 + 命令写 MCP）
- 做法：主配置走模板，MCP 通过 `openclaw mcp set` 注入。
- 优点：兼顾稳定性和 MCP 兼容性。
- 风险：最终状态分散，需统一回读校验。

**推荐：方案 A（必要时对 MCP 使用 C 的补充写入）。**

## 3. 最终执行顺序（按你的要求固化）

1. 写入 `openclaw.json`，并 `openclaw config validate` 验证通过。  
2. workspace 转换。  
3. prompt 处理。  
4. skill 转换。  
5. mcp 转换。
6. （可选）识别校验（`verify-recognition` 开启时执行，且作为最后一步）。

> 说明：第 1 步的“最小可用 openclaw.json”必须直接基于 `openclaw-template.json` 生成，并先通过 `openclaw config validate`。
> 说明：第 6 步用于补充运行侧识别验证，避免“Schema 合法但未被 OpenClaw 正确识别”。

## 4. 字段级映射规则

## 4.1 基础元数据
- `agentName`：作为默认标识来源。
  - 有 `subAgents` 时：可用于校验/补全 `agents.list[*].id`。
  - 无 `subAgents` 时：不强制写入 `agents.list`，直接复用模板 agent 配置。
- `runtimeType`：当前仅接受 `openclaw`，非 `openclaw` 直接报错终止。

## 4.2 model 转换规则

### 输入
- `model[]`（多 provider，含 `is_primary`）

### 输出（OpenClaw）
- `models.mode`：默认 `merge`。
- `models.providers.<provider>`：
  - `apiKey` <- `apiKey`
  - `baseUrl` <- 可选映射（若源有）
  - `api` <- provider 映射表推导（例如 OpenAI 兼容走 `openai-completions`）
  - `models[]` <- 每个 model 的 id/name/context/maxTokens/input/reasoning
- `agents.defaults.model.primary` <- `is_primary=true` 的 `provider/name`
- `agents.defaults.model.fallbacks` <- 其它 `provider/name`
- `agents.defaults.models["provider/name"].alias` <- `name`

### 约束
- 必须且仅允许一个 `is_primary=true`，否则报错。
- 源字段 `resaoning` 视为拼写错误，按 `reasoning` 处理并给出 warning。

## 4.3 tool 转换规则
- `tools.profile` -> `tools.profile`
- `tools.allowed[]` -> `tools.allow[]`
- `tools.deny[]` -> `tools.deny[]`
- 未给定时不强制覆盖模板默认值。

## 4.4 subagent 转换规则

### 有 `subAgents` 时
- 删除模板中的默认单 agent 占位（逻辑删除，不保留 `agent.default` 概念）。
- 生成 `agents.list[]`：
  - `id` <- `subAgents[].id`
  - `workspace` <- 解析 `${workspace.xxx}` 后的绝对路径
  - `model` <- 如为空则继承 `agents.defaults.model`
  - `skills` <- subagent 级技能名列表（见第 6 节）
  - `default`：若存在 `id=main`，则 `main` 设为 `true`；否则第一项 `true`

### 无 `subAgents` 时
- 直接复用 `openclaw-template.json` 中的 agent 配置（不新建 `agents.list`）。
- 仅刷新 `agents.defaults.model`：
  - `primary` <- `is_primary=true` 的 `provider/name`
  - `fallbacks` <- 其它 `provider/name`
- 同步刷新 `agents.defaults.models` 的 alias 映射，避免残留模板中的固定 `deepseek/*`。

## 5. workspace 转换规则

### 5.1 目录创建
- 按 `workspace.<name>.path` 处理。
- `default` 目录不主动创建（按你的要求“default 除外”）。
- 非 default workspace 若不存在则创建。

### 5.2 初始文件复制
- 以 default workspace 为源，复制其初始文件到每个非 default workspace。
- 初始文件集合：default 目录下已存在的 bootstrap 文件（如 `AGENTS.md/SOUL.md/TOOLS.md/...`）。
- 若 default workspace 目录不存在或为空，则回退到仓库模板源 `transfor/agent_template/external/openclaw/workspace/` 作为初始文件来源。

### 5.3 AGENTS/SOUL 替换
- 对每个 workspace：
  - 若配置了 `AGENTS` 文件路径，则覆盖写入 `<workspace>/AGENTS.md`
  - 若配置了 `SOUL` 文件路径，则覆盖写入 `<workspace>/SOUL.md`
- 文件路径按 `agent-spec.yaml` 所在目录解析相对路径。

### 5.4 workspace 示例
输入（agent-spec）：
```yaml
workspace:
  default:
    path: ~/.openclaw/workspace
    AGENTS: ./external/openclaw/workspace/AGENTS.md
    SOUL: ./external/openclaw/workspace/SOUL.md
  workspaceA:
    path: ~/.openclaw/workspaceA
    AGENTS: ./external/openclaw/workspaceA/AGENTS.md
```

结果：
- 创建 `~/.openclaw/workspaceA/`（default 不主动创建）。
- 先把 default 初始文件复制到 `workspaceA`。
- 再用 `workspaceA` 的 `AGENTS` 覆盖 `~/.openclaw/workspaceA/AGENTS.md`。
- `SOUL` 未配置则保留复制结果。

## 6. prompt 处理规则

### 输入来源
- `prompt.system`
- `prompt.system_file[]`（glob）

### 处理方式
- 收集“内联字符串 + 引用文件内容”，按出现顺序拼接。
- `system_file` 的 glob 结果按路径字典序排序后拼接，确保幂等。
- 在 default workspace 的 `AGENTS.md` 头部追加（prepend）一个区块：
  - 标记头：`## Imported System Prompt`
  - 每段内容前写来源注释（inline/file path）
- 若 `AGENTS.md` 不存在则先创建再写入。
- 为避免重复注入：写入块带固定 begin/end marker，重复运行时先替换 marker 块。

### 6.1 prompt 示例
输入（agent-spec）：
```yaml
prompt:
  system: |
    You are a helpful assistant.
  system_file:
    - ./prompt/system.md
```

写入到 `~/.openclaw/workspace/AGENTS.md` 的头部区块示例：
```md
<!-- BEGIN: IMPORTED_SYSTEM_PROMPT -->
## Imported System Prompt

### Source: inline(prompt.system)
You are a helpful assistant.

### Source: file(./prompt/system.md)
...文件内容...
<!-- END: IMPORTED_SYSTEM_PROMPT -->
```

## 7. skill 转换规则

### 7.1 全局 skill（你的 2.1 规则）
- 安装位置：`~/.openclaw/skills`
- 命令：`clawhub install <slug> --workdir ~/.openclaw --dir skills`

### 7.2 subagent skill（你的 2.1 规则）
- 安装位置：对应 subagent 的 workspace 下 `skills/`
- 命令：`clawhub install <slug> --workdir <workspace-path> --dir skills`

### 7.3 三类 skill 输入处理
- `installed=local_link`：从 `source` 复制/链接到目标 skills 目录。
- `installed=local_created`：生成 `<skill>/SKILL.md`。
- `installed=tool_installed`：按上面的 clawhub 命令安装。
- `tool_installed` 若缺少 `name/slug`，视为配置错误并中止（避免安装未知技能）。

### 7.4 skill 示例
输入（agent-spec）：
```yaml
skills:
  - name: tdd
    source: ./skills/tdd
    installed: local_link
  - name: security-review
    inline: |
      # Security Review Skill
      ...
    installed: local_created
  - name: python-review
    installed: tool_installed
```

转换动作：
1. `local_link`：复制 `./skills/tdd` -> `~/.openclaw/skills/tdd/`
2. `local_created`：创建 `~/.openclaw/skills/security-review/SKILL.md`
3. `tool_installed`：执行  
   `clawhub install python-review --workdir ~/.openclaw --dir skills`

subagent 示例（`dev` 绑定 `~/.openclaw/workspaceA`）：
- 执行  
  `clawhub install python-review --workdir ~/.openclaw/workspaceA --dir skills`
- 产物目录：`~/.openclaw/workspaceA/skills/python-review/`

## 8. mcp 转换规则

### 8.1 方式 A（local_link）
- 先将 `source` 目录复制到 `~/.openclaw/mcp/<name>/`。
- 将 `config` 按 **YAML** 解析后转换为 JSON 对象，再写入 `mcp.servers.<name>`。
- 其中本地脚本路径重写到 `~/.openclaw/mcp/<name>/...`。

### 8.2 方式 B（remote_link）
- 直接把 `config`（YAML -> JSON）映射写入 `mcp.servers.<name>`。
- 支持：
  - stdio：`command/args/env/cwd`
  - remote：`url/headers`

### 8.3 方式 C（tool_installed）
- 按你的要求通过 mcporter 处理：
  - 使用 `mcporter config add`（http/stdio）或 `mcporter config import ... --copy` 落盘。
  - 再将 mcporter 中该 server 的结果转换为 OpenClaw `mcp.servers.<name>` 并写入。
- 注意：mcporter 负责“发现/管理 MCP 定义”，OpenClaw 仍以 `mcp.servers` 为最终运行配置。
- 若 `mcporter` 只产出中间配置而未能导出 server 对象，则该项标记为失败并终止，禁止静默跳过。
- 说明：mcporter 语义更接近“注册/导入”，不是通用“下载器”；转换器需把“下载”理解为“拿到可用 server 定义并入库”。

### 8.4 mcp 示例
方式 A（`local_link`）输入：
```yaml
mcp:
  - config: |
      name: deploy
      transport: stdio
      command: python
      args:
        - ~/.openclaw/mcp/my-local-mcp/deploy/xx.py
      env:
        API_KEY: xxx
    source: ./mcp/my-local-mcp/deploy
    installed: local_link
```
输出（openclaw.json 片段）：
```json
{
  "mcp": {
    "servers": {
      "deploy": {
        "command": "python",
        "args": ["~/.openclaw/mcp/deploy/xx.py"],
        "env": { "API_KEY": "xxx" }
      }
    }
  }
}
```

方式 B（`remote_link`）输入：
```yaml
mcp:
  - config: |
      name: remote-sse
      transport: sse
      url: http://127.0.0.1:8080/mcp/sse
      headers:
        Authorization: Bearer ${MCP_SSE_TOKEN}
    installed: remote_link
```
输出（openclaw.json 片段）：
```json
{
  "mcp": {
    "servers": {
      "remote-sse": {
        "url": "http://127.0.0.1:8080/mcp/sse",
        "headers": { "Authorization": "Bearer ${MCP_SSE_TOKEN}" }
      }
    }
  }
}
```

方式 C（`tool_installed`）输入：
```yaml
mcp:
  - name: filesystem
    installed: tool_installed
```
动作示例：
1. `mcporter config add filesystem --command npx --arg -y --arg @modelcontextprotocol/server-filesystem --arg ~/`
2. 读取 `mcporter` 中的 `filesystem` 定义
3. 回填到 `openclaw.json` 的 `mcp.servers.filesystem`

## 9. openclaw.json 写入与模板规则

### 9.1 模板文件
- 第一优先模板：`transfor/agent_template/openclaw-template.json`（先做最小集）。
- 新增：`transfor/agent_template/openclaw.json.tmpl`（可选增强版；用于占位符渲染）。
- 允许 `${xxx}` 占位，建议至少包括：
  - `${gateway.auth.token}`
  - `${models.providers}`
  - `${agents.defaults}`
  - `${agents.list}`（仅有 `subAgents` 时需要）
  - `${tools}`
  - `${mcp.servers}`

### 9.2 渲染规则
- 渲染后必须得到合法 JSON（不保留 `${}`）。
- 空对象/空数组策略：
  - 对 schema 必需字段保留最小合法值。
  - 可选字段为空时可省略。
- 路径统一做 `~` 展开并标准化为绝对路径后再落盘（workspace/mcp/source 等）。

### 9.3 校验规则
- 写入目标：`~/.openclaw/openclaw.json`
- 校验命令：`openclaw config validate`
- 识别校验（可选，且必须在最后一步执行）：
  - `openclaw config get agents.defaults.model --json`
  - 有 `subAgents` 时：`openclaw config get agents.list --json`
  - 有 `tools` 时：`openclaw config get tools --json`
  - 有 `mcp` 时：`openclaw mcp list --json` 与 `openclaw mcp show <name> --json`
  - `openclaw skills list --eligible --json`
  - `openclaw skills check --json`
- 失败处理：
  - 输出错误路径与字段；
  - 保留 `~/.openclaw/openclaw.json.bak.<timestamp>` 以便回滚。
- 建议采用原子写入：先写临时文件，再替换正式文件，最后校验；失败则回滚备份。
- `gateway.auth.token` 若未提供，转换器生成随机 token（与模板占位可二选一），禁止写入空值。

## 10. 异常与幂等
- 幂等：重复执行不重复注入 prompt、不重复安装同名 skill（已存在则跳过或 update）。
- 任一步失败即停止，不进入后续步骤。
- 所有文件改动输出变更清单（创建/覆盖/跳过）。
- 占位符保护：最终写入前若仍存在 `${...}` 且该字段要求“已实值化”，应直接报错。

## 11. 对现有 openclaw-template.json 的修订建议
- 保留：`gateway/models/agents/tools/session` 主结构。
- 修正：
  - `primary` 中多余 `}`（`deepseek/deepseek-chat}` -> `deepseek/deepseek-chat`）。
  - 把“注释性中文占位值”替换为 `${...}` 占位。
  - 明确 `agents.list` 为 subagent 入口，避免只靠 `agents.defaults`。

## 12. 预校验清单（编码前）
1. `agent-spec.yaml` 语义校验（主模型唯一、workspace 引用存在、source 路径存在）。
2. 模板占位完整性校验（无未替换 `${...}`）。
3. `openclaw config validate` 必过。
4. workspace 文件存在性校验（default 源文件是否可复制）。
5. skill/mcp 外部命令可用性校验（`clawhub`、`mcporter`）。

## 13. 下一步编码边界（经你确认后执行）
- 仅实现：`transfer/agent-spec -> openclaw` 转换器。
- 第一版先覆盖：`openclaw.json + workspace + prompt + skills + mcp`。
- 不在第一版实现 OpenCode 输出。

## 14. 校验
新增 _verify_openclaw_recognition，在 config validate 通过后继续检查：
openclaw config get agents.defaults.model --json
openclaw config get agents.list --json（有 subAgents 时）
openclaw config get tools --json（有 tools 时）
openclaw mcp list --json + openclaw mcp show <name> --json（有 mcp 时）
openclaw skills list --eligible --json
openclaw skills check --json
---

## 参考依据（在线）
- OpenClaw config CLI: https://docs.openclaw.ai/cli/config
- OpenClaw configuration reference: https://docs.openclaw.ai/gateway/configuration-reference
- OpenClaw MCP CLI: https://docs.openclaw.ai/cli/mcp
- OpenClaw ClawHub: https://docs.openclaw.ai/tools/clawhub
- OpenClaw Skills: https://docs.openclaw.ai/tools/skills
- OpenCode Config: https://opencode.ai/docs/config/
- OpenCode Providers: https://opencode.ai/docs/providers/
- OpenCode Agents: https://opencode.ai/docs/agents/
- OpenCode MCP servers: https://opencode.ai/docs/mcp-servers/

## 参考依据（本机实测）
- `openclaw config file`
- `openclaw config schema`
- `openclaw config validate`
- `openclaw mcp set --help`
- `clawhub --help`
- `mcporter config add --help`
- `opencode debug paths`
