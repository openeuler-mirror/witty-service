# TDD (Test-Driven Development) Skill

## When to Use

- Writing new features
- Refactoring existing code
- Fixing bugs with regression tests
- "TDD workflow" keyword mentioned
- "write tests first" mentioned

## Workflow

### 1. Write the Test First

```python
def test_feature_x():
    # Arrange
    input_data = ...
    expected = ...
    
    # Act
    result = feature_x(input_data)
    
    # Assert
    assert result == expected
```

### 2. Run the Test (Should Fail)

```bash
pytest test_module.py -v
```

### 3. Write Minimal Code to Pass

Implement only what's needed to make the test pass.

### 4. Refactor

Clean up the code while keeping tests green.

### 5. Repeat

Continue the cycle for each new feature.

## Best Practices

- One assertion per test (when practical)
- Descriptive test names
- Test edge cases
- Keep tests independent
- Use fixtures for common setup
